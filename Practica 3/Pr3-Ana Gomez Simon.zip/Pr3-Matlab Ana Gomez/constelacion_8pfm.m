function constelacion = constelacion_8pfm()
x = [-7 -5 -3 -1 1 3 5 7];
y = [0 0 0 0 0 0 0 0];
constelacion = [y' x'];