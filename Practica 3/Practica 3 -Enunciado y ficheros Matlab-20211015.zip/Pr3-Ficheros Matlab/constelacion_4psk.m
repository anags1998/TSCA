function constelacion = constelacion_4psk()
theta = [1 3 7 5]*pi/4;
constelacion = [cos(theta)' sin(theta)'];
