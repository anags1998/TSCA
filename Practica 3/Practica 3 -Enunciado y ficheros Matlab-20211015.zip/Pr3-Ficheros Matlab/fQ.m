function q = Q(x)

q = 1/2 * erfc(x/sqrt(2));