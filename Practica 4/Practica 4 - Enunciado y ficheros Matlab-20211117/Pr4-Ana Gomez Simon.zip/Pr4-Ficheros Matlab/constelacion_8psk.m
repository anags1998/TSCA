function constelacion = constelacion_8psk()
theta = [5 4 2 3 6 7 0 1]*pi/4;
constelacion = [cos(theta)' sin(theta)'];
