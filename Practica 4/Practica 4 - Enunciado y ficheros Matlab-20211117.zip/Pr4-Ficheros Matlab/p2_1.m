clear all;
close all;
numero_de_bits=120;
bits = fuente(numero_de_bits);

% Constelación 8psk
constelacion = constelacion_tcm_8psk();
ver_constelacion(constelacion);
Eav=mean(sum(constelacion.^2,2))
M = size(constelacion,1)

% Crear Trellis
G = [1 1 1;
     1 0 1];
nbits_sin_codificar = 1;
trellis = crear_trellis(G, nbits_sin_codificar)
ver_trellis(trellis)

% Codificación TCM bits 
bits_cod = codificar_trellis(bits, trellis)

[Ik,Qk] = asignacion_simbolos(bits_cod,constelacion);

fp = 3000;
fb = 300;
fm = 4*fp;
fs = fb / log2(M);

[pulso,retardo] = rcos(fm,fs,0.5,5);
[I,Q] = filtro_tx(Ik,Qk,fm,fs,pulso);
[xI,xQ] = modulador(I,Q,fm,fp);
x=xI+xQ;

%----------------------------------------
% CANALES: ideal, awgn
% Canal ideal
r = x;

% Canal_awgn
% Es = sum(pulso.^2);
% Eb = Es/log2(M);
% EbN0dB = 0
% n = canal_awgn(x,Eb,EbN0dB);
% r=x+n;
%---------------------------------------

% Demodulador
[xI,xQ] = demodulador(r,fm,fp);
[I,Q]   = filtro_rx(xI,xQ,pulso);
[Ik,Qk] = muestreo(I,Q,fm,fs,retardo);
D = distancias(Ik,Qk,constelacion);

bitsr   = decodificar_trellis(trellis, D)
bits
Pb = sum(bits ~= bitsr )/numero_de_bits


